const express = require('express');

// app config 
const app = express();

const port = 3000;

// middleware config
app.use(express.json());


// define item list 

let itemList = [

    {id:1, name : "monisha ms"},

];

// api routes
// CRUD operations
app.get('/api/v1/items', (req, res)=>{
    return res.json(itemList);
});
app.post('/api/v1/items', (req, res)=>{
    let newItem = {
        id: itemList.length + 1,
        name :  req.body.name,


    }
    itemList.push(newItem);
    res.status(201).json(newItem);
});
app.put('/api/v1/items/:id', (req, res)=>{
    let itemId =req.params.id;
    let updateItem = req.body;
    let index = itemList.findIndex(item =>itemId === itemId);

    if (index !== 1) {
        itemList[index] = updatedItem;
        res.json(updatedItem);
    }else{
        res.status(404).json({message:"Item not found"});
    }
});
app.delete('/api/v1/items/:id', (req, res)=>{
    let itemId = req.params.id;
    let index = itemsList.findIndex(item => itemId === itemId);

    if(index !== -1){
        let deletedItem = itemList.splice(index,1);
        res.json(deletedItem[0]);
    }else{
        res.status(404).json({message:"Item not found"});
    }
});




// listeners
app.listen(port , () => {
    console.log(`Listening on port ${port}`);

})